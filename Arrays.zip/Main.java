import java.util.Scanner;

class Main {
  public static void main(String[] args) {

    //If Class and main method already created Start copying from here 
    Scanner scanner = new Scanner(System.in);
    String[] listOfStudents = new String[3];

    System.out.println("Enter the names of the Students");
    for(int i =0; i < listOfStudents.length; i+=1)
    {
      System.out.print("Student " + (i+1) + " : ");
      listOfStudents[i] = scanner.nextLine();
    }

 

    System.out.println("Do you want to Display \nAll Student [y/n]?\n2.Single Student[s]?");
    String answer = scanner.nextLine().toLowerCase();
    if(answer.equals("yes") || answer.equals("y")){
      System.out.println("These are all the Students you entered");
      int i = 1;
      for(String studentName : listOfStudents){
        System.out.println("Student " + i + " : " + studentName);
        i++;
      }  
    }else if(answer.equals("s")){
      System.out.print("Enter the index of the Student: ");
      int studentIndex = scanner.nextInt();
      if(studentIndex > listOfStudents.length){
        System.out.println("That Index is out of Bounds!!!! Index should be between 1 and " + listOfStudents.length);
      }else{
          System.out.println("Your Student is: "+ listOfStudents[studentIndex - 1]);
      }
      
    }
    else{
      System.exit(1);
    }//end of IF statement

    //and end here 

  }//end of main method
}//end of Main Class